document.getElementById('authForm').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent form reload

    const userData = {
        Id: 2,
        Username: document.getElementById('username').value.trim(),
        FirstName: document.getElementById('firstName').value.trim(),
        LastName: document.getElementById('lastName').value.trim(),
        Email: document.getElementById('email').value.trim(),
        Phone: document.getElementById('phone').value.trim(),
        Role: "Supervisor",
        Password: document.getElementById('password').value.trim(),
        Verified: true,
        Token: "1"
    };
    console.log(userData);
    try {
        const response = await fetch('https://localhost:7096/api/User/register', {
            method: 'POST',
            body: JSON.stringify(userData),
            headers: {
                'Content-Type': 'application/json'
            },
            
        });

        if (!response.ok) {
            throw new Error(`Registration failed: ${response.status}`);
        }

        const result = await response.json();
        console.log('Registration success:', result);

    } catch (error) {
        console.error('Error registering user:', error);
    }
});

// const IdInput = 2 ;
// const registerBtn = document.querySelector('#regID');
// const firstName = document.querySelector('#firstName');
// const lastName = document.querySelector('#regID');
// const username = document.querySelector('#username');
// const email = document.querySelector('#email');
// const contactNumber = document.querySelector('#phone');
// const role = "Supervisor";
// const password = document.querySelector('#password');
// const verified = true;
// const token = 3;




// function addUser (Id, username, FirstName, LastName, Email, ContactNumber, Role, Password, Verified, Token){
//     const body = {
//         Id : Id,
//         username:username,
//         FirstName:FirstName,
//         LastName:LastName,
//         Email: Email,
//         ContactNumber:ContactNumber,
//         Role:Role,
//         Password:Password,
//         Verified:Verified,
//         Token:Token
//     };

//     fetch('https://localhost:7096/api/User/register', {
//         method: 'POST',
//         body: JSON.stringify(userData),
//         headers: {
//             'Content-Type': 'application/json'
//         },
        
//     })
    
//     .then(data => data.json())
//     .then(response => console.log(response));
    
// }


// registerBtn.addEventListener('click', function(){
//     addUser(IdInput.valueOf, username.valueOf, firstName.valueOf,lastName.valueOf,email.valueOf,contactNumber.valueOf,role.valueOf , password.valueOf, verified.valueOf , token.valueOf )
// });







